# Whatsapp Autochat With AIML

Download as zip

    https://github.com/rahadiana/WhatsappAutoChat/archive/master.zip
OR

Add To Android Studio Project from Git

    https://github.com/rahadiana/WhatsappAutoChat.git


Video Tutorial 

[configure Program-o](https://youtu.be/UpORcU0Xkm8)

[Whatsapp Auto Chat](https://youtu.be/UpORcU0Xkm8)
